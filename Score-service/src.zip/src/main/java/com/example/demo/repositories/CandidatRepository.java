package com.example.demo.repositories;

public interface CandidatRepository {
    
}
